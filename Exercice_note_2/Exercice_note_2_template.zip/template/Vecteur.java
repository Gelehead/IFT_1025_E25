public class Vecteur {
    
    public Vecteur(double[] elements){

    }

    public void setElement(int index, double valeur){
        
    }

    public double getElement(int index){
        return 0;
    }

    public double dotProduct(Vecteur v){
        return 0;
    }


    @Override
    public String toString(){
        return "";
    }

    public void afficher(){
        System.out.println(this.toString());
    }
}