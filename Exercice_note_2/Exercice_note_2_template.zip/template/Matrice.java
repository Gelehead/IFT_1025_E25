public class Matrice{
    
    public Matrice(int lignes, int cols){

    }

    public void additionnerScalaire(double n){
        
    }

    public void multiplierScalaire(double n){

    }

    public Matrice dotProduct(Matrice m){ 
        return null;
    }

    public double getCell(int ligne, int col){
        return 0;
    }

    public void setCell(int ligne, int col, double valeur){

    }

    public Vecteur getLine(int ligne){
        return null;
    }

    public Vecteur getCol(int col){
        return null;
    }

    public void afficher(){
        
    }

    public Matrice transpose(){
        return null;
    }

    public static Matrice identite(int n){
        return null;
    }

    public int getLignes(){
        return 0;
    }

    public int getColonnes(){
        return 0;
    }

}