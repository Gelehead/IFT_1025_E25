Exemple de modification du programme MVC1 pour changer le modèle
seulement : plutôt que de compter un nombre total, on considère la
moyenne des nombres ajoutés.

Le Modèle est modifié, la Vue et le Contrôleur restent exactement
pareils.
