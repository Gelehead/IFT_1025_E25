Exemple de modification du programme MVC1 pour utiliser une interface
en ligne de commande à la place d'une interface JavaFX, aka modifier
la Vue sans modifier le Modèle.
