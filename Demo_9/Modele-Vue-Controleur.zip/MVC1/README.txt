Exemple de petit programme MVC

Le programme est un simple petit compteur dans lequel on peut
additionner des nombres.

